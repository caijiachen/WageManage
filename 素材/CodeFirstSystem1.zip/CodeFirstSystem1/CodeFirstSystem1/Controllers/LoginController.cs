﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CodeFirstSystem1.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace CodeFirstSystem1.Controllers
{
    public class LoginController : Controller
    {

        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Register()
        {
           
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult Login()
        {
            return View();

        }

    }
}