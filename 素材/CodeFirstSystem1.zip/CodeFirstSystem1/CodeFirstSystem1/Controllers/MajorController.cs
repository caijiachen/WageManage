﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CodeFirstSystem1.Models;

namespace CodeFirstSystem1.Controllers
{
    public class MajorController : Controller
    {
        AccountEntities db = new AccountEntities();
        // GET: Major
        public ActionResult Index()
        {
            List<Major> list = db.Major.ToList();
            return View(list);
        }
        public ActionResult Index2()
        {
            return View();
        }
    }
}